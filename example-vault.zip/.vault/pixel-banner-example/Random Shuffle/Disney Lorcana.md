---
icon: 🏰🌐🎬🌳
y: 10
---

# Disney Lorcana

lets add random shuffle here :)