---
icon: "😇"
banner: "[[father-and-child.jpg]]"
banner-inline-title-color: hotpink
---

