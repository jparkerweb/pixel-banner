---
banner: "[[pixel-banner-images/in-the-midst-of-a-crystalline-world-an-intricat.jpg]]"
icon: 🦉
icon-bg-color: rgba(176, 39, 39, 0.42)
icon-border-radius: 100
icon-padding-x: 33
icon-padding-y: 34
banner-x: 32
banner-y: 15
banner-height: 470
content-start: 426
---

