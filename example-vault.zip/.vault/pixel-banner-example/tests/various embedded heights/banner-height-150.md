---
icon: "😡"
banner: "[[file-folders.jpg]]"
banner-height: 150
content-start: 150
icon-y: 50
icon-x: 50
---
# banner-height: 150

