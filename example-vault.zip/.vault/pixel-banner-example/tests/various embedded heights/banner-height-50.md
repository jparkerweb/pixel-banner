---
icon: 👁️
banner: "[[file-folders.png]]"
banner-height: 50
content-start: 50
icon-size: "50"
icon-x: "80"
---
# banner-height: 50

