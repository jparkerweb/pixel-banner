---
banner: "[[code.png]]"
---

note content

![[example-embedded]]

some more content here