---
icon: v2.20.4 - ⭐ The Icon has Landed
banner: "[[shooting-star.png]]"
content-start: 386
icon-size: "30"
icon-x: 50
icon-y: "-20"
icon-bg-color: "#00000070"
icon-padding-x: "100"
icon-padding-y: "20"
icon-font-weight: bold
banner-display: cover
banner-height: 350
banner-x: 50
banner-y: 50
---

Example `banner icon` in a note ⭐