---
banner: "[[father-and-child.jpg]]"
icon: 💀 Emoji Time 🏮
icon-x: "80"
content-start: 400
icon-color: papayawhip
icon-size: "34"
icon-bg-color: "#2c2d9d80"
icon-padding-x: "20"
icon-padding-y: "15"
icon-border-radius: "50"
---

