---
banner: "[[father-and-child.jpg]]"
icon: 💀 Emojii Time 🏮
icon-x: "80"
content-start: 400
icon-color: papayawhip
icon-size: "34"
icon-bg-color: "#2c2d9d80"
icon-padding: "10"
icon-border-radius: "50"
---

