---
banner: "[[pixel-banner-image.jpg]]"
icon-bg-color: rgba(0, 85, 255, 0.52)
icon-border-radius: 100
icon-padding-x: 49
icon-padding-y: 0
icon-size: 78
banner-height: 330
content-start: 331
icon: Fish...
---

# Spider note