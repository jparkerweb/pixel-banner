# 📁 Embedded Note in Subfolder

This shouldn't have a banner applied as the `Direct Children Only` toggle is applied to the `notes` directory in `Folder Image` settings.
